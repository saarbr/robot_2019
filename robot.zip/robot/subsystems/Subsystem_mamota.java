/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018-2019 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Subsystem_mamota extends SubsystemBase {

    WPI_TalonSRX MamotaMovment;

    WPI_VictorSPX MamotaIntake;

    private static Subsystem_mamota subsystem_mamota;


  private Subsystem_mamota() {

    MamotaMovment = new WPI_TalonSRX(1);

    MamotaIntake = new WPI_VictorSPX(2);



  }


     public static Subsystem_mamota getinstance() {
      if (subsystem_mamota == null) { 
        subsystem_mamota = new Subsystem_mamota();
      }
      return subsystem_mamota;

    }


  


      public void MamotaMovment_Control(double power) {
        MamotaMovment.set(ControlMode.PercentOutput, power);
      }


      public void MamotaIntake_Control(double power) {
        MamotaIntake.set(ControlMode.PercentOutput , power);
      }





      







  @Override
  public void periodic() {
    
    
    
    
    // This method will be called once per scheduler run
  }
}

/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018-2019 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Subsystem_intake extends SubsystemBase {
    

    Solenoid solenoid1;

    WPI_TalonSRX intakeMovment1;

    WPI_TalonSRX intakeMovment2;

    WPI_VictorSPX intakeCollection;

    private static Subsystem_intake subsystems_intake;

  private Subsystem_intake() { 
      
      solenoid1 = new Solenoid(1);

      intakeMovment1 = new WPI_TalonSRX(1);
      intakeMovment2 = new WPI_TalonSRX(2);
      intakeMovment2.follow(intakeMovment1);
      intakeMovment1.setInverted(true);


      intakeCollection = new WPI_VictorSPX(1);

  }


  public static Subsystem_intake getinstance() {
      if (subsystems_intake == null) {
          subsystems_intake = new Subsystem_intake();
      }
      return subsystems_intake;
  }




  public void Piston(boolean t){
      solenoid1.set(t);
  }

  public boolean getPiston(){
    return solenoid1.get();
  }



  public void IntakeControl(double power){
      intakeMovment1.set(ControlMode.PercentOutput, power)
  }


  public void intakeCollection(double power) { 
      intakeCollection.set(ControlMode.PercentOutput, power);
  }





  @Override
  public void periodic() {
    
    
    
    
    // This method will be called once per scheduler run
  }
}
